#pragma once

/****
 * 	CLAUDIO TORTORELLI - Claudiosoft 2005 
 */

#define TEM  0x01
#define SOF  0xc0
#define DHT  0xc4
#define JPGA 0xc8
#define DAC  0xcc
#define RST  0xd0
#define SOI  0xd8
#define EOI  0xd9
#define SOS  0xda
#define DQT  0xdb
#define DNL  0xdc
#define DRI  0xdd
#define DHP  0xde
#define EXP  0xdf
#define APP  0xe0
#define JPG  0xf0
#define COM  0xfe

/* Sample quantization tables from JPEG spec --- only needed for
 * guesstimate of quality factor
 */
static int std_luminance_quant_tbl[64] = {
  16,  11,  12,  14,  12,  10,  16,  14,
  13,  14,  18,  17,  16,  19,  24,  40,
  26,  24,  22,  22,  24,  49,  35,  37,
  29,  40,  58,  51,  61,  60,  57,  51,
  56,  55,  64,  72,  92,  78,  64,  68,
  87,  69,  55,  56,  80, 109,  81,  87,
  95,  98, 103, 104, 103,  62,  77, 113,
 121, 112, 100, 120,  92, 101, 103,  99
};

static int std_chrominance_quant_tbl[64] = {
  17,  18,  18,  24,  21,  24,  47,  26,
  26,  47,  99,  66,  56,  66,  99,  99,
  99,  99,  99,  99,  99,  99,  99,  99,
  99,  99,  99,  99,  99,  99,  99,  99,
  99,  99,  99,  99,  99,  99,  99,  99,
  99,  99,  99,  99,  99,  99,  99,  99,
  99,  99,  99,  99,  99,  99,  99,  99,
  99,  99,  99,  99,  99,  99,  99,  99
};

static int *deftabs[2] = { std_luminance_quant_tbl, std_chrominance_quant_tbl };

static unsigned int getWordMoto (FILE *stream)
{
  register unsigned int temp;

  temp=(unsigned int) (getc(stream)<<8);
  return (unsigned int) getc(stream) | temp;
}


/////////////////////////////////////////////////////////////////////////////

class CGdiPlusBitmap
{
////////// costruttori
public:
	CGdiPlusBitmap()
	{ 
		m_pBitmap = NULL; 
		m_quality = 0.0;
			
		GdiplusStartupInput gdiplusStartupInput;
		GdiplusStartup(&m_gdiplusToken, &gdiplusStartupInput, NULL);		
	}

	virtual ~CGdiPlusBitmap()		
	{ 
		Empty();
		GdiplusShutdown(m_gdiplusToken);
	}

//////////////// attributi
public:
	Bitmap*			m_pBitmap;

protected:
	double			m_quality;
	CString			m_filepath;
	CLSID			m_Clsid;
	ULONG_PTR		m_gdiplusToken;
		

////////////// metodi
public:
	void Empty()
	{ 
		if (m_pBitmap) 
			delete m_pBitmap; 
		m_pBitmap = NULL; 
	
		m_quality = 0;
		m_filepath = "";
	}

	BOOL Load(CString filePath)
	{
		try
		{
			if (m_pBitmap)
				Empty();

			m_filepath = filePath;
			m_pBitmap = Bitmap::FromFile(filePath.AllocSysString());
			
			if (!m_pBitmap)
				return FALSE;

			if (m_pBitmap->GetLastStatus() == Gdiplus::Ok)
			{			
				FILE* pFileHandle = fopen(filePath, "rb");
				if (!pFileHandle)
					return FALSE;

				double quality = 0.0;
				GetJpegQuality(pFileHandle, &m_quality);
				fclose(pFileHandle);

				char ext[8];
				_splitpath(filePath, NULL, NULL, NULL, ext);
				GetCLSID(ext, m_Clsid);

				return TRUE;
			}		
			return FALSE;
		}
		catch (CException* pEx)
		{
			pEx->Delete();
			AfxMessageBox("Si � verificato un errore in Load\nCod. Messaggio: 098", MB_ICONSTOP);
			return FALSE;
		}
	}

	/**
	 * NB assicurarsi che la foto non sia attualmente aperta dall'applicazione chiamante
	 * se il nome rimane lo stesso
	 */
	BOOL Save(CString filePath = "", BOOL bUsedExternal = FALSE)
	{
		try
		{
			if (!m_pBitmap)
				return FALSE;

			CString file;
			if (!filePath.IsEmpty())
				file = filePath;
			else
				file = m_filepath;
			
			//if (m_pBitmap->GetLastStatus() == Gdiplus::Ok)
			{			
				char drive[8];
				char path[4096];
				char fname[4096];
				char ext[8];
				_splitpath(file, drive, path, fname, ext);
				
				if (!GetCLSID(ext, m_Clsid))
					return FALSE;

				if (bUsedExternal)
				{
					// non utilizza qui dentro il file tmp. gestione rimandata fuori di qui
					WCHAR wFname[4096];
					MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, file, -1, wFname, 4095);
								
					if (m_pBitmap->Save(wFname, &m_Clsid, NULL) != Ok)
						return FALSE;
				}
				else
				{
					// usa file tmp per consentire una "sovrascrittura" eventuale
					char fnameTmp[4096];
					sprintf(fnameTmp, "%sTmp", fname);

					char fPathTmp[4096];
					_makepath(fPathTmp, drive, path, fnameTmp, ext);
					
					WCHAR wFname[4096];
					MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, fPathTmp, -1, wFname, 4095);
								
					if (m_pBitmap->Save(wFname, &m_Clsid, NULL) != Ok)
						return FALSE;

					Empty();

					if (!DeleteFile(file))
						return FALSE;

					if (rename(fPathTmp, file) != 0)
						return FALSE;
					
					if (!Load(file))
						return FALSE;					
				}
				
				return TRUE;
			}		

			return FALSE;
		}
		catch (CException* pEx)
		{
			pEx->Delete();
			AfxMessageBox("Si � verificato un errore in Load\nCod. Messaggio: 098", MB_ICONSTOP);
			return false;
		}
	}

	double	GetQuality(){return m_quality;} // qualit� del jpeg

	CString	GetFilepath(){return m_filepath;} // file path della foto

	CLSID GetCurrentCLSID(){return m_Clsid;} // Ritorna il CLSID attuale
		
	// ritorna l'angolo di rotazione rispetto all'originale in gradi
	int GetRotationAngle()
	{
		try
		{
			// memorizzato in PropertyTagPageName per convenzione...
			UINT size = m_pBitmap->GetPropertyItemSize(PropertyTagPageName);
			PropertyItem* propertyItem = (PropertyItem*)malloc(size);
			m_pBitmap->GetPropertyItem(PropertyTagPageName, size, propertyItem);

			int angle = 0;
			if(propertyItem->type == PropertyTagTypeASCII)
				angle = atoi((char*)propertyItem->value);
			free(propertyItem);

			return angle;
		}
		catch (CException* pEx)
		{
			pEx->Delete();
			AfxMessageBox("Si � verificato un errore in GetRotationAngle\nCod. Messaggio: 112", MB_ICONSTOP);
			return 0;
		}
	};

	BOOL SetRotationAngle(int newAngle)
	{
		PropertyItem* propertyItemWrite = new PropertyItem;
			
		try
		{
			char propertyValue[32];
			ZeroMemory(propertyValue, 32*sizeof(char));			
			sprintf(propertyValue, "%d", newAngle);
			propertyValue[31] = '\0';

			propertyItemWrite->id = PropertyTagPageName;
			propertyItemWrite->length = 32;  // string length including NULL terminator
			propertyItemWrite->type = PropertyTagTypeASCII; 
			propertyItemWrite->value = propertyValue;

			if (m_pBitmap->SetPropertyItem(propertyItemWrite) != Ok)
			{		
				if (propertyItemWrite)
					delete propertyItemWrite;
				return FALSE;
			}	
			
			if (propertyItemWrite)
				delete propertyItemWrite;
		
			return TRUE;
		}
		catch (CException* pEx)
		{
			pEx->Delete();
			if (propertyItemWrite)
				delete propertyItemWrite;
			AfxMessageBox("Si � verificato un errore in GetRotationAngle\nCod. Messaggio: 113", MB_ICONSTOP);
			return FALSE;
		}
	};

	// ritorna il modello della fotocamera digitale che ha scattato la foto
	CString GetCameraModel()
	{		
		try
		{
			UINT size = m_pBitmap->GetPropertyItemSize(PropertyTagEquipModel);
			PropertyItem* propertyItem = (PropertyItem*)malloc(size);
			m_pBitmap->GetPropertyItem(PropertyTagEquipModel, size, propertyItem);

			CString ret;
			if(propertyItem->type == PropertyTagTypeASCII)
				ConvertValueToString(propertyItem->type, propertyItem->value, propertyItem->length, ret);
			free(propertyItem);
		   
			return ret;
		}
		catch (CException* pEx)
		{
			pEx->Delete();
			AfxMessageBox("Si � verificato un errore in GetRotationAngle\nCod. Messaggio: 114", MB_ICONSTOP);
			return "";
		}
	};

	/**
	 * Lo posso scrivere sulla bitmap in memoria perch� la criptazione viene fatta su quella
	 * e il salvataggio sull'hd � a cura di chi cripta
	 */
	BOOL SetMagicNumber(double Sum)
	{	
		PropertyItem* propertyItem = new PropertyItem;
						
		// in PropertyTagImageDescription
		try
		{	
			char propertyValue[100];
			ZeroMemory(propertyValue, 100*sizeof(char));
			sprintf(propertyValue, "%.3f", Sum);
			propertyValue[99] = 0;
			 			   
			propertyItem->id = PropertyTagImageDescription;
			propertyItem->length = 100;  // string length including NULL terminator
			propertyItem->type = PropertyTagTypeASCII; 
			propertyItem->value = propertyValue;

			if (m_pBitmap->SetPropertyItem(propertyItem) != Ok)
			{
				if (propertyItem)
					delete propertyItem;
				return FALSE;
			}

			if (propertyItem)
				delete propertyItem;
		
			return TRUE;
		}
		catch (CException* pEx)
		{
			pEx->Delete();
			if (propertyItem)
				delete propertyItem;
			AfxMessageBox("Si � verificato un errore in SetMagicNumber\nCod. Messaggio: 115", MB_ICONSTOP);
			return FALSE;
		}
	}

	BOOL GetMagicNumber(double& CheckSum)
	{		
		try
		{
			UINT size = m_pBitmap->GetPropertyItemSize(PropertyTagImageDescription);

			PropertyItem* propertyItem = (PropertyItem*)malloc(size);

			m_pBitmap->GetPropertyItem(PropertyTagImageDescription, size, propertyItem);

			BOOL bRet = TRUE;
			if(propertyItem->type == PropertyTagTypeASCII)
			{		
				CString magStr;
				ConvertValueToString(propertyItem->type, propertyItem->value, propertyItem->length, magStr);
				CheckSum = atof(magStr);
			}
			else 
				bRet = FALSE;

			if (propertyItem)
				free(propertyItem);

			return bRet;
		}
		catch (CException* pEx)
		{
			pEx->Delete();
			AfxMessageBox("Si � verificato un errore in GetMagicNumber\nCod. Messaggio: 116", MB_ICONSTOP);
			return FALSE;
		}
	}

	CString GetFocalLength()
	{
		try
		{
			UINT size = m_pBitmap->GetPropertyItemSize(PropertyTagExifFocalLength);

			PropertyItem* propertyItem = (PropertyItem*)malloc(size);

			m_pBitmap->GetPropertyItem(PropertyTagExifFocalLength, size, propertyItem);

			CString fLen;
			if(propertyItem->type == PropertyTagTypeRational)
			{		
				ConvertValueToString(propertyItem->type, propertyItem->value, propertyItem->length, fLen);
			}
			
			if (propertyItem)
				free(propertyItem);

			return fLen;
		}
		catch (CException* pEx)
		{
			pEx->Delete();
			AfxMessageBox("Si � verificato un errore in GetFocalLength", MB_ICONSTOP);
			return "";
		}
	}

	CString GetDateTime()
	{
		try
		{
			UINT size = m_pBitmap->GetPropertyItemSize(PropertyTagDateTime);

			PropertyItem* propertyItem = (PropertyItem*)malloc(size);

			m_pBitmap->GetPropertyItem(PropertyTagDateTime, size, propertyItem);

			CString date;
			if(propertyItem->type == PropertyTagTypeASCII)
			{		
				ConvertValueToString(propertyItem->type, propertyItem->value, propertyItem->length, date);
			}
			
			if (propertyItem)
				free(propertyItem);

			return date;
		}
		catch (CException* pEx)
		{
			pEx->Delete();
			AfxMessageBox("Si � verificato un errore in GetDateTime", MB_ICONSTOP);
			return "";
		}
	}		


	/**
	 * Alloca la bitmap in uno stream in memoria
	 */
	BOOL GetMemBitmap(CGdiPlusBitmap* pMemBitmap)
	{
		if (!pMemBitmap)
			return FALSE; 

		// imposta la qualit� della compressione
		EncoderParameters newEncoderParameters;

		newEncoderParameters.Count = 1;
		newEncoderParameters.Parameter[0].Guid = EncoderQuality;
		newEncoderParameters.Parameter[0].Type = EncoderParameterValueTypeLong;
		newEncoderParameters.Parameter[0].NumberOfValues = 1;
		newEncoderParameters.Parameter[0].Value = &m_quality;

		// crea lo stream associato all'immagine
		IStream* pIStream = NULL;
		if(CreateStreamOnHGlobal(NULL, TRUE, (LPSTREAM*)&pIStream) != S_OK)
			return FALSE;
		
		// salva l'immagine in memoria fornendo anche i parametri di compressione
		Status SaveStatus = m_pBitmap->Save(pIStream, &m_Clsid, &newEncoderParameters);
		if(SaveStatus != Ok)
			return FALSE;
				
		pMemBitmap->m_pBitmap = Bitmap::FromStream(pIStream);

		return TRUE;
	}

	/*
	BOOL GetIplFromGdi(IplImage* pIpl)
	{		
		if (pIpl)
			cvReleaseImage(&pIpl);
		pIpl = NULL;

		HBITMAP hBitmap = NULL;
		Status status = m_pBitmap->GetHBITMAP(NULL, &hBitmap);
		if( status != Ok )
			return FALSE;
			
		BITMAP bm;   
		GetObject( hBitmap, sizeof(BITMAP), &bm );

		pIpl = cvCreateImage(cvSize(bm.bmWidth, bm.bmHeight), IPL_DEPTH_8U, bm.bmBitsPixel/8);

		memcpy(pIpl->imageData, bm.bmBits, pIpl->imageSize);		
		
		DeleteObject(hBitmap);

		return TRUE;
	}
	*/

	/**
	 * Ritorna il CLSID corrispondente all'estensione	 
	 */
	BOOL GetCLSID(CString ext, CLSID& Clsid)
	{
		WCHAR wFormat[4096];
			
		if (strcmp(strlwr(ext.GetBuffer(0)), ".bmp") == 0)
			MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, "image/bmp", -1, wFormat, 4095);			
		if (strcmp(strlwr(ext.GetBuffer(0)), ".jpg") == 0)
			MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, "image/jpeg", -1, wFormat, 4095);			
		if (strcmp(strlwr(ext.GetBuffer(0)), ".tif") == 0)
			MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, "image/tiff", -1, wFormat, 4095);			

		try
		{
			UINT  num = 0;          // number of image encoders
			UINT  size = 0;         // size of the image encoder array in bytes

			ImageCodecInfo* pImageCodecInfo = NULL;

			GetImageEncodersSize(&num, &size);
			if(size == 0)
				return FALSE;  // Failure

			pImageCodecInfo = (ImageCodecInfo*)(malloc(size));
			if(pImageCodecInfo == NULL)
				return FALSE;  // Failure

			GetImageEncoders(num, size, pImageCodecInfo);

			for(UINT j = 0; j < num; ++j)
			{
				if( wcscmp(pImageCodecInfo[j].MimeType, wFormat) == 0 )
				{
					Clsid = pImageCodecInfo[j].Clsid;
					free(pImageCodecInfo);
					return TRUE;  // Success
				}    
			}

			free(pImageCodecInfo);
			return FALSE;  // Failure
		}
		catch (CException* pEx)
		{
			pEx->Delete();
			return FALSE;
		}

		return TRUE;
	}

	operator Gdiplus::Bitmap*() const	{ return m_pBitmap; }

/////////////////////////////////////////////////////////////////////////////////

protected:

	/**
	 * Converte in stringa il valore letto dall'exif del tipo "index"
	 * Il buffer iniziale � pdata di lunghezza ndatalen
	 * La stringa letta � szdest
	 */
	const bool ConvertValueToString(WORD index, void* pdata, int ndatalen, CString& szdest)
	{
		szdest = "";
		switch (index)
		{
		   case 1:
		   case 7:
		   {
				//PropertyTagTypeByte & PropertyTagTypeUndefined
				CString szc = "";
				unsigned char *pc = (unsigned char*)(pdata);
				for(int i = 0; i < ndatalen; i++)
				{
					szc.Format("%d ",pc[i]);
					szdest += szc;
				}
		   }
		   break;
		   case 2:
		   {
				//PropertyTagTypeASCII
				char *pc = (char*)(pdata);
				szdest.Format("%s",pc);
		   }
		   break;
		   case 3:
		   {
			   //PropertyTagTypeShort
				CString szc = "";
				unsigned short *pus = (unsigned short*)(pdata);
				int tmplen = ndatalen / sizeof(unsigned short);
				for(int i = 0; i < tmplen; i++)
				{
					szc.Format("%hd ",pus[i]);
					szdest += szc;
				}    
		   }
		   break;
		   case 4:
		   {
			   //PropertyTagTypeLong
				CString szc = "";
				unsigned long *pul = (unsigned long*)(pdata);
				int tmplen = ndatalen / sizeof(unsigned long);
				for(int i = 0; i < tmplen; i++)
				{
					szc.Format("%ld ",pul[i]);
					szdest += szc;
				}        
		   }
		   break;
		   case 5:
		   {
			   //PropertyTagTypeRational
			   //RATIONAL (PAIR OF UNSIGNED LONG INTEGERS)
				CString szc = "";
				unsigned long *pul = (unsigned long*)(pdata);
				int tmplen = ndatalen /sizeof(unsigned long);
				for(int i = 0; i < tmplen; i++)
				{
					//szc.Format("(%ld,%ld) ",pul[i],pul[i+1]);
					szc.Format("%.2f ",pul[i]/(double)pul[i+1]);
					i++;
					szdest += szc;
				}        
		   }
		   break;
		   case 9:
		   {
				//PropertyTagTypeSLONG
				CString szc = "";
				long *pl = (long*)(pdata);
				int tmplen = ndatalen /sizeof(long);
				for(int i = 0; i < tmplen; i++)
				{
					szc.Format("%ld ",pl[i]);
					szdest += szc;
				}        
		   }
		   break;
		   case 10:
		   {
				//PropertyTagTypeSRational
				//SRATIONAL (PAIR OF LONG INTEGERS)
				CString szc = "";
				long *pl = (long*)(pdata);
				int tmplen = ndatalen /sizeof(long);
				for(int i = 0; i < tmplen; i++)
				{
					//szc.Format("(%ld,%ld) ",pl[i++],pl[i]);
					szc.Format("%.2f ",pl[i]/(double)pl[i+1]);
					szdest += szc;
				}        
		   }
		   break;
		   default:
			   return false;
		 }
		 return true;
	}

	
	long GetJpegQuality(FILE *stream, double *pQuality)
	{
		try
		{
			char *prefix = "";
			boolean continueAfterEOI = true;
			boolean recurseIntoThumbnails = false;
			long startingOffset = 0;

			int marker;
			int c, c2, c3, c4, c5, row, col, i;
			unsigned int height, aword;
			long length;
			unsigned char huff[16];
			long totalBytesRead;
			char *str;
			char *newPrefix;
			  
			totalBytesRead=0L;

			while (1) 
			{
				c=getc(stream);
				if (c==EOF)
					break;
				totalBytesRead++;
				/* marker prefix? */
				if (c!=0xff)
					continue;
				/* get marker code, skipping fill bytes */
				do 
				{
					c=getc(stream);
					totalBytesRead++;
				} 
				while (c==0xff);
				if (c==EOF)
					break;
				/* ignore stuffed FF/00 sequences */
				if (c==0)
					continue;
				/* OK, we've apparently found a marker */
				marker=c;
				length=0L;
				switch (marker) 
				{
				case SOI:
					break;
				case DRI:
					length=(long) getWordMoto(stream);
					aword = getWordMoto(stream);
					totalBytesRead+=4L;
					length-=4L;
					break;
				case APP+0:
				case APP+1:
				case APP+2:
				case APP+3:
				case APP+4:
				case APP+5:
				case APP+6:
				case APP+7:
				case APP+8:
				case APP+9:
				case APP+10:
				case APP+11:
				case APP+12:
				case APP+13:
				case APP+14:
				case APP+15:
					length=(long) getWordMoto(stream);
					totalBytesRead+=2L;
					length-=2L;

					if (marker==APP+0 && length>=14L) 
					{
						char signature[5];
					
						fread(signature, 1, 5, stream);
						totalBytesRead+=5L;
						length-=5L;
						if (memcmp(signature, "JFIF", 5)==0) 
						{
							unsigned int dpiX, dpiY, thumbX, thumbY;
							long thumbBytes;
							  
							aword = getWordMoto(stream);
							c=getc(stream);
							dpiX=getWordMoto(stream);
							dpiY=getWordMoto(stream);
							thumbX=(unsigned int) getc(stream);
							thumbY=(unsigned int) getc(stream);
							totalBytesRead+=9L;
							length-=9L;
							thumbBytes = (long)thumbX*(long)thumbY*3L;
							length-=thumbBytes;
							totalBytesRead+=thumbBytes;
							while (thumbBytes--)
								getc(stream);
						} 
						else if (memcmp(signature, "JFXX", 5)==0) 
						{
							int extension;
							unsigned int thumbX, thumbY;
							long thumbBytes;
							  
							extension=getc(stream);
							totalBytesRead++;
							length--;
							switch (extension) 
							{
							case 0x10:
								if (recurseIntoThumbnails) 
								{
									long bytes;
								  
									newPrefix=(char *) malloc(strlen(prefix)+5);
									if (newPrefix==NULL) 
									{
										fprintf(stderr, "out of memory\n");
										exit(-1);
									}
									strcpy(newPrefix, prefix);
									strcat(newPrefix, "    ");
									bytes=GetJpegQuality(stream, pQuality);
									totalBytesRead+=bytes;
									length-=bytes;
									free(newPrefix);
								} 
								else 
								{
									while (length>0L) 
									{
										getc(stream);
										totalBytesRead++;
										length--;
									}
								}
								break;
							case 0x11:
								thumbX=(unsigned int) getc(stream);
								thumbY=(unsigned int) getc(stream);
								totalBytesRead+=2L;
								length-=2L;
								for (i=0; i<256; i++) 
								{
									int red, green, blue;
									red=getc(stream);
									green=getc(stream);
									blue=getc(stream);
									totalBytesRead+=3L;
									length-=3L;
								}
								thumbBytes = (long)thumbX*(long)thumbY;
								length-=thumbBytes;
								totalBytesRead+=thumbBytes;
								while (thumbBytes--)
								getc(stream);
								break;
							case 0x13:
								thumbX=(unsigned int) getc(stream);
								thumbY=(unsigned int) getc(stream);
								totalBytesRead+=2L;
								length-=2L;
								thumbBytes = (long)thumbX*(long)thumbY*3L;
								length-=thumbBytes;
								totalBytesRead+=thumbBytes;
								while (thumbBytes--)
									getc(stream);
								break;
							default:
								break;
							}
						} 
						else 
						{
							/* Unrecognized APP0 marker */
							while (length>0L) 
							{
								c = getc(stream);
								totalBytesRead++;
								length--;
							}
						}
					}
					/* Print any remaining data in the APP marker */
					if (length) 
					{
						while (length>0L) 
						{
							c = getc(stream);
							totalBytesRead++;
							length--;
						}
					}
					break;
				case COM:
					length=(long) getWordMoto(stream);
					totalBytesRead+=2L;
					length-=2L;
					while (length>0L) 
					{
						c = getc(stream);
						totalBytesRead++;
						length--;
					}
					break;
				/* the following all have the same syntax and fall through to one parser */
				case SOF+0:
					str="SOF0 (baseline DCT Huffman)";
					goto frame;
				case SOF+1:
					str="SOF1 (extended sequential DCT Huffman)";
					goto frame;
				case SOF+2:
					str="SOF2 (progressive DCT Huffman)";
					goto frame;
				case SOF+3:
					str="SOF3 (spatial lossless Huffman)";
					goto frame;
				case SOF+9:
					str="SOF9 (extended sequential DCT arithmetic)";
					goto frame;
				case SOF+10:
					str="SOF10 (progressive DCT arithmetic)";
					goto frame;
				case SOF+11:
					str="SOF11 (spatial lossless arithmetic)";
					goto frame;
				/* the following SOF markers are for differential coding;
				they are listed on page B-2 of CD 10918-1, but for some
				reason are not listed on B-6 and B-7, where the SOF syntax
				is given.  This suggests that the syntax may be different
				for these markers, but it doesn't seem to be defined
				anywhere else in the document.  */
				case SOF+5:
					str="SOF5 (differential sequential DCT Huffman)";
					goto frame;
				case SOF+6:
					str="SOF6 (differential progressive DCT Huffman)";
					goto frame;
				case SOF+7:
					str="SOF7 (differential spatial Huffman)";
					goto frame;
				case SOF+13:
					str="SOF13 (differential sequential DCT arithmetic)";
					goto frame;
				case SOF+14:
					str="SOF14 (differential progressive DCT arithmetic)";
					goto frame;
				case SOF+15:
					str="SOF15 (differential spatial arithmetic)";
					goto frame;
				case DHP:
				str="DHP";
				  
				frame:
				length=(long) getWordMoto(stream);
				totalBytesRead+=2L;
				length-=2L;
				c=getc(stream);
				height=getWordMoto(stream);
				aword=getWordMoto(stream);
				c2=getc(stream);
				totalBytesRead+=6L;
				length-=6L;
				while (c2--) 
				{
					c3=getc(stream);
					c4=getc(stream);
					c5=getc(stream);
					totalBytesRead+=3L;
					length-=3L;
				}
					break;
				case SOS:
					length=(long) getWordMoto(stream);
					totalBytesRead+=2L;
					length-=2L;
					c2=getc(stream);
					totalBytesRead++;
					length--;
					while (c2--) 
					{
						c3=getc(stream);
						c4=getc(stream);
						totalBytesRead+=2L;
						length-=2L;
					}
					c=getc(stream);
					c2=getc(stream);
					c3=getc(stream);
					totalBytesRead+=3L;
					length-=3L;
					break;
				case DQT:
					length=(long) getWordMoto(stream);
					totalBytesRead+=2L;
					length-=2L;

					while (length>0L) 
					{
						int tableindex;
						int *table = NULL;
						double cumsf = 0.0, cumsf2 = 0.0;
						int allones = 1;
						
						c=getc(stream);
						totalBytesRead++;
						length--;
						tableindex = c & 0x0f;
						if (tableindex < 2)
							table = deftabs[tableindex];

						for (row=0; row<8; row++) 
						{
							for (col=0; col<8; col++) 
							{
								unsigned int val;
								
								if (c>>4) 
								{
									val=getWordMoto(stream);
									totalBytesRead+=2L;
									length-=2L;
								} 
								else 
								{
									val=(unsigned int) getc(stream);
									totalBytesRead++;
									length--;
								}
								if (table) 
								{
									double x;
									/* scaling factor in percent */
									x = 100.0 * (double)val / (double)table[row*8+col];
									cumsf += x;
									cumsf2 += x * x;
									/* separate check for all-ones table (Q 100) */
									if (val != 1) allones = 0;
								}
							}
						}
						if (table) 
						{
							double  var;
							  
							cumsf /= 64.0;	/* mean scale factor */
							cumsf2 /= 64.0;
							var = cumsf2 - (cumsf * cumsf); /* variance */
							if (allones)		/* special case for all-ones table */
								*pQuality = 100.0;
							else if (cumsf <= 100.0)
								*pQuality = (200.0 - cumsf) / 2.0;
							else
								*pQuality = 5000.0 / cumsf;
						}
					}
					break;
				case DHT:
					length=(long) getWordMoto(stream);
					totalBytesRead+=2L;
					length-=2L;
					while (length>0L) 
					{
						c=getc(stream);
						totalBytesRead++;
						length--;
						for (i=0; i<16; i++) 
						{
							huff[i]=(unsigned char) getc(stream);
						}
					totalBytesRead+=16L;
					length-=16L;
					for (i=0; i<16; i++) 
					{
						while (huff[i]--) 
						{
							c2 = getc(stream);
							totalBytesRead++;
							length--;
						}
					}
				}
					break;
				case DAC:
					length=(long) getWordMoto(stream);
					totalBytesRead+=2L;
					length-=2L;
					while (length>0L) 
					{
						c=getc(stream);
						c2=getc(stream);
						totalBytesRead+=2L;
						length-=2L;
					}
					break;
				case RST+0:
				case RST+1:
				case RST+2:
				case RST+3:
				case RST+4:
				case RST+5:
				case RST+6:
				case RST+7:
					break;
				case DNL:
					length=(long) getWordMoto(stream);
					aword = getWordMoto(stream);
					totalBytesRead+=4L;
					length-=4L;
					break;
				case EOI:
					break;
				case EXP:
					length=(long) getWordMoto(stream);
					c=getc(stream);
					totalBytesRead+=3L;
					length-=3L;
					break;
				case TEM:
					break;
				default:
					length=(long) getWordMoto(stream);
					totalBytesRead+=2L;
					length-=2L;
					while (length>0L) 
					{
						c=getc(stream);
						totalBytesRead++;
						length--;
					}
					break;
				} /* end switch (marker) */
				if (marker==EOI && !continueAfterEOI)
					break;
			} /* end while */

			return totalBytesRead;
		}
		catch (CException* pEx)
		{
			pEx->Delete();
			AfxMessageBox("Si � verificato un errore in GetJpegQuality\nCod. Messaggio: 097", MB_ICONSTOP);
			return -1;
		}
	}

};
