/**
 *  Copyright (C) 2005  Claudio Tortorelli - E-mail torto@virgilio.it
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA*
 *	
 */

// FileTxtMarkup1.cpp: implementation of the CFileTxtMarkup class.
//
//////////////////////////////////////////////////////////////////////

#include "FileTxtMarkup.h"


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

/**
 * If tag is furnished then it search for the first occurrence
 * and locate the cursor
 */
CFileTxtMarkup::CFileTxtMarkup(string txtFilePath, string tag)
{
	m_FilePath = txtFilePath; 	
	
	char fname[1024];
	_splitpath(txtFilePath.c_str(),NULL,NULL,fname,NULL);
	m_FileName = fname;	

	if (!Open())
		cout << "Error: impossible to open the file!";

	m_CurLnText = new char[LINE_DIMENSION];
	
	CountLines();

	m_LineCursor = 1; // start of file
	m_LastModifiedLine = -1;
	m_bModified = false;

	if (!tag.empty())
	{
		int tagLn = SearchWord(tag);
		if (tagLn >= 0)
			GoToLine(tagLn);
	}	
}


CFileTxtMarkup::CFileTxtMarkup(CFileTxtMarkup& file)
{
	*this = file;
}

CFileTxtMarkup::~CFileTxtMarkup()
{
	Close();
	
	delete[] m_CurLnText;

	if (m_FileOut.is_open())
		CloseOut();	
}

//////////////////////////////////////////////////////////////////////
// Methods
//////////////////////////////////////////////////////////////////////

void CFileTxtMarkup::CountLines()
{
	m_nLines = 0;
   
	char line[LINE_DIMENSION];
   	while (!eof())
    {               
	    getline(line, LINE_DIMENSION);        
        
        m_nLines++;        
    }   

	// reset pos
	Rewind();
}

/**
 * Set the internal cursor and return the line position
 */
int CFileTxtMarkup::GoToNextEmptyLn()
{
	bool bFound = false;
	
	while (!bFound && !eof())
    {                                  
        getline(m_CurLnText,LINE_DIMENSION);
        
		if (strcmp(m_CurLnText, "") == 0)
        {
            bFound = true;                       
			m_LineCursor++;
            break;
        }   
		m_LineCursor++;
    }    
    
	return m_LineCursor;
}

/**
 * Set the internal cursor and return the line position
 */
int	CFileTxtMarkup::GoToNextFillLn()
{
	bool bFound = false;
	
    while (!bFound && !eof())
    {                                  
        getline(m_CurLnText,LINE_DIMENSION);
        
        if (strcmp(m_CurLnText, "") != 0)
        {
            bFound = true;                       
			m_LineCursor++;
            break;
        }   
		m_LineCursor++;
    }    
    
	return m_LineCursor;
}

/**
 * search for the previous empty line
 */
int	CFileTxtMarkup::GoToPrevEmptyLn()
{
	bool bFound = false;

	while (m_LineCursor >= 0 && !bFound)
	{
		GoToLine(m_LineCursor-1);
		if (strcmp(m_CurLnText, "") == 0)
			bFound = true;
	}

	return m_LineCursor;
}

/**
 * search for the previous not empty line
 */
int CFileTxtMarkup::GoToPrevFillLn()
{
	bool bFound = false;

	while (m_LineCursor >= 0 && !bFound)
	{
		GoToLine(m_LineCursor-1);
		if (strcmp(m_CurLnText, "") != 0)
			bFound = true;
	}

	return m_LineCursor;
}

/**
 * go to end of file, return line cursor number
 */
int CFileTxtMarkup::GoToEOF()
{
	while (!eof())
    {                                  
        getline(m_CurLnText,LINE_DIMENSION);                  
		m_LineCursor++;
    }   

	return m_LineCursor;
}

/**
 * set m_LineCursor to line number specified (if it's possible)
 */
bool CFileTxtMarkup::GoToLine(int lineNum)
{
	if (lineNum < 0 || lineNum > m_nLines)
		return false;

	if (lineNum < m_LineCursor)
		Rewind();

	while (!eof() && m_LineCursor != lineNum)
    {                                  
        getline(m_CurLnText,LINE_DIMENSION);        
        m_LineCursor++;        
    }   

	return true;
}

/**
 * retrieve current line content 
 */
void CFileTxtMarkup::GetCurLnContent(string& curLn) 
{
	curLn.resize(LINE_DIMENSION);
	for (int i = 0; i < LINE_DIMENSION; i++)
		curLn[i] = m_CurLnText[i]; 
}

/**
 * return to begin of file
 */
void CFileTxtMarkup::Rewind()
{
	Open();
	m_LineCursor = 1;
}

/**
 * search 'word'. If bCurLn the search is done only on the current line
 * If word is founded then the return value is > -1
 */
int CFileTxtMarkup::SearchWord(string word, bool bCaseSensitive, bool bCurLn)
{	
	bool bRes = false;

	int retVal = -1;

	if (bCurLn)
	{
		if (BFSearch(word.c_str(), m_CurLnText, bCaseSensitive))
			retVal = m_LineCursor;
	}
	else
	{
		int tmpCur = m_LineCursor;

		Rewind();

		while (m_LineCursor < m_nLines && !bRes)
		{
			GoToNextFillLn();

			bRes = BFSearch(word.c_str(), m_CurLnText, bCaseSensitive);	
		}

		if (bRes)
			retVal = m_LineCursor;

		GoToLine(tmpCur);// recover old cursor position
	}

	return retVal;
}


/**
 * count substring's instances on all file
 * the search is Case Sensitive. 
 */
int CFileTxtMarkup::CountMatchSubStr(string subStr)
{
	int nCount = 0;

	int tmpCur = m_LineCursor;

	Rewind(); 

	int M = subStr.size();

	string pattStr = m_CurLnText;
	
	while (m_LineCursor < m_nLines)
	{
		GoToNextFillLn();

		int pos = pattStr.find(subStr);
		while (pos != -1)		
		{
			pos = pattStr.find(subStr, pos+M);
			nCount++;
		}
	}

	GoToLine(tmpCur);// recover old cursor position

	return nCount;
}

bool CFileTxtMarkup::InsertLn(string lnContent, bool bReplace)
{
	if (m_LineCursor < 0)
		return false;

	OpenOut();

	int oldLnCur = m_LineCursor;

	Rewind();

	while (m_LineCursor < oldLnCur)
    {                                  
        getline(m_CurLnText,LINE_DIMENSION);
		m_FileOut.write(strcat(m_CurLnText,"\n"),strlen(m_CurLnText)+1);
        m_LineCursor++;        
    }

	if (strcmp (&lnContent.c_str()[lnContent.size()-1], "\n") != 0)
		lnContent += "\n";

	m_FileOut.write(lnContent.c_str(),strlen(lnContent.c_str()));

	if (bReplace)
		getline(m_CurLnText,LINE_DIMENSION);

	while (peek() != EOF)
	{
		getline(m_CurLnText,LINE_DIMENSION);
		m_FileOut.write(strcat(m_CurLnText,"\n"),strlen(m_CurLnText)+1);
		m_LineCursor++;        
	}

	CloseOut();

	m_LastModifiedLine = oldLnCur;

	if (!bReplace)
		m_nLines++;

	GoToLine(oldLnCur);
	
	m_bModified = true;

	return true;
}

bool CFileTxtMarkup::DeleteLn(int lnNum)
{
	if (lnNum < -1 || lnNum > m_nLines)
		return false;

	if (lnNum == -1)
		lnNum = m_LineCursor;

	OpenOut();

	int oldLnCur = m_LineCursor;

	Rewind();

	while (m_LineCursor < lnNum)
    {                                  
        getline(m_CurLnText,LINE_DIMENSION);
		m_FileOut.write(strcat(m_CurLnText,"\n"),strlen(m_CurLnText)+1);
        m_LineCursor++;        
    }

	getline(m_CurLnText,LINE_DIMENSION);

	while (peek() != EOF)
	{
		getline(m_CurLnText,LINE_DIMENSION);
		m_FileOut.write(strcat(m_CurLnText,"\n"),strlen(m_CurLnText)+1);
		m_LineCursor++;        
	}

	CloseOut();

	m_LastModifiedLine = oldLnCur;

	m_nLines--;

	if (oldLnCur < m_nLines)
		GoToLine(oldLnCur);
	else
		GoToLine(m_nLines);
	
	m_bModified = true;
	return true;
}




//////////////////////////////////////////////////////////////////////
// Protected Methods
//////////////////////////////////////////////////////////////////////

CFileTxtMarkup& CFileTxtMarkup::operator ==(CFileTxtMarkup& file)
{
	m_FilePath = file.GetFilePath(); 	
	
	m_FileName = file.GetFileName();	

	m_nLines = file.GetNumLines();

	m_FileOut = file.m_FileOut;

	string tmpStr;
	file.GetCurLnContent(tmpStr);
	sprintf(m_CurLnText, tmpStr.c_str());

	m_LastModifiedLine = file.m_LastModifiedLine;

	m_LineCursor = file.m_LineCursor;

	m_bModified = file.m_bModified;

	return *this;
}

/**
 * // Written by Jack Handy - jakkhandy@hotmail.com
 *
 * Modified by Claudio Tortorelli - CLAUDIOSOFT 2005 
 * Pattern matching
 * input: pWild pattern to search, pString text where search
 * output: 0 if there isn't pWild, 1 otherwise
 */
bool CFileTxtMarkup::Wildcmp(const char* pWild, const char* pString) 
{	
	const char* cp = NULL;
	const char* mp = NULL;

	while ((*pString) && (*pWild != '*')) 
	{
		if ((*pWild != *pString) && (*pWild != '?')) 
		{
			return 0;
		}
		pWild++;
		pString++;
	}

	while (*pString) 
	{
		if (*pWild == '*') 
		{
			if (!*++pWild) 
			{
				return 1;
			}
			mp = pWild;
			cp = pString+1;
		} 
		else if ((*pWild == *pString) || (*pWild == '?')) 
		{
			pWild++;
			pString++;
		} 
		else 
		{
			pWild = mp;
			pString = cp++;
		}
	}

	while (*pWild == '*') 
	{
		pWild++;
	}
	return !*pWild;
}

bool CFileTxtMarkup::Open(fstream* pFile)
{
	if (is_open())
		close();
	
	open(m_FilePath.c_str(), ios::in );		
	clear();

	return is_open();	 
}

void CFileTxtMarkup::Close(fstream* pFile)
{
	close();
}

bool CFileTxtMarkup::OpenOut(ofstream* pFile)
{
	if (!pFile)
		pFile = &m_FileOut;
	
	if (pFile->is_open())
		pFile->close();

	char drive[8];
	char path[1024];
	char fname[1024];
	_splitpath(m_FilePath.c_str(), drive, path, fname, NULL);
	char tmpfname[2048];
	_makepath(tmpfname,drive,path,fname,".tmp");

	
	pFile->open(tmpfname, ios::in | ios::out | ios::trunc);
	pFile->clear();

	return pFile->is_open();	 
}

void CFileTxtMarkup::CloseOut(ofstream* pFile)
{
	if (!pFile)
		pFile = &m_FileOut;

	pFile->close();

	char drive[8];
	char path[1024];
	char fname[1024];
	_splitpath(m_FilePath.c_str(), drive, path, fname, NULL);
	char tmpfname[2048];
	_makepath(tmpfname,drive,path,fname,".tmp");
	
	Close();
	remove(m_FilePath.c_str());
	rename(tmpfname, m_FilePath.c_str());
	Open();
}


/**
 * Brute Force string search 
 */
bool CFileTxtMarkup::BFSearch(const string pattern, const string text, bool bCaseSensitive)
{	
	bool bRes = false;

	int i = 0;
	int j = 0;

	int M = pattern.size();
	int N = text.size();

	while (i < M && j < N)
	{
		if (bCaseSensitive)
		{
			if (pattern[i] == text[j])
			{
				i++;
				j++;

				continue;
			}
		}
		else
		{
			if (pattern[i] == text[j] || 
				((int)pattern[i]+32) == text[j] ||
				((int)pattern[i]-32) == text[j])
			{
				i++;
				j++;

				continue;
			}
		}

		i = 0;
		j = j - i + 1;
	}

	if (i == M)
		bRes = true;

	return bRes;
}


