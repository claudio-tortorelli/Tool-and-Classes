#include "FileTxtMarkup.h"

using namespace std;

int main(int argc, char *argv[])
{
    CFileTxtMarkup ff("", "");
		
	return EXIT_SUCCESS;
}
 
