// Claudio Tortorelli - CLAUDIOSOFT 2005 

#if !defined(AFX_FILETXTMARKUP1_H__EC5C98A4_63F6_4075_B826_08474FFBB804__INCLUDED_)
#define AFX_FILETXTMARKUP1_H__EC5C98A4_63F6_4075_B826_08474FFBB804__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif 

// base
#include <vector>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <io.h>
#include <conio.h>
#include <fstream>
#include <streambuf>

// namespace
using namespace std;

// macro
#define LINE_DIMENSION		1024

// structs

class CFileTxtMarkup : public ifstream
{
////////////// Constructors/Destructors
public:
	CFileTxtMarkup(string txtFilePath, string tag = "");
	CFileTxtMarkup(CFileTxtMarkup& file);// copy constructor

	virtual ~CFileTxtMarkup();


/////////////// 
//	Attributes
///////////////
protected:
	// construction members
	string			m_FilePath;	

	// managed members	
	ofstream		m_FileOut; // file OutPut
		
	string			m_FileName;

	char*			m_CurLnText;

	int				m_nLines; // number of lines of the file
	int				m_LastModifiedLine;

	int				m_LineCursor;// specifies in which line we are working. It is modified by many methods

	bool			m_bModified;


/////////////// 
//	Methods
///////////////
public:

//////// file properties
////////
	string			GetFilePath(){return m_FilePath;}
	
	string			GetFileName(){return m_FileName;}

	int				GetNumLines(){return m_nLines;}
	int				GetLastModifiedLn(){return m_LastModifiedLine;}
	
	bool            IsFileOpen(){return is_open();}

	int				GetLineNumChar(){return LINE_DIMENSION;}


//////// methods to change the file
////////
	bool			InsertLn(string lnContent, bool bReplace = false);
	bool			DeleteLn(int lnNum = -1);

//////// methods to emulate an ini file
////////
	virtual bool	WriteKeyValue(string key, string val){return true;} // write a key with its value on current line
	virtual string	ReadKeyValue(string key){return "";}// read key's value on current line
	virtual bool	FindKeyLn(string key){return true;}// search key on file and if there is one locate the cursor 

//////// method to access file properties (don't change the file state)
////////
	void			Rewind();// reopen the file to position to start

	int				GoToNextEmptyLn();// search for the next empty line
	int				GoToNextFillLn();// search for the next not empty line

	int				GoToPrevEmptyLn();// search for the previous empty line
	int				GoToPrevFillLn();// search for the previous not empty line

	int				GoToEOF();// go to the end of file
	bool			GoToLine(int lineNum); // set m_LineCursor

	int				SearchWord(string word, bool bCaseSensitive = false, bool bCurLn = false);// search 'word' 

	int				CountMatchSubStr(string subStr); // count substring's instances

	void			GetCurLnContent(string& curLn); // retrieve current line

	void			AddLnCursor() {m_LineCursor++;} // force to add 1 to the cursor
	void			SubLnCursor() {m_LineCursor--;}	// force to subctract 1 to the cursor

	bool			SaveAs(string filePath = "");// save the status on file

protected: 
	CFileTxtMarkup&	operator ==(CFileTxtMarkup& file);

	void			CountLines();

	bool			Open(fstream* pFile = NULL);
	bool			OpenOut(ofstream* pFile = NULL);
	void			Close(fstream* pFile = NULL);
	void			CloseOut(ofstream* pFile = NULL);

	bool			Wildcmp(const char* pWild, const char* pString); // pattern matching	
	bool			BFSearch(const string pattern, const string text, bool bCaseSensitive); // string matching	

};
#endif 
